<?php $__env->startSection('content'); ?>
<div class="card bg-dark text-light">
    <div class="card-header">
        <h2 class="mb-0">Photo Gallery</h2>
    </div>
    <div class="card-body">
        <a href="<?php echo e(route('admin.photos.create')); ?>" class="btn btn-custom mb-3">Add New Photo</a>

        <table class="table table-bordered admin-table">
            <thead>
                <tr>
                    <th class="text-center">ID</th>
                    <th class="text-center">Title</th>
                    <th class="text-center">Image</th>
                    <th class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="text-center align-middle text-black"><b><?php echo e($photo->id); ?></b></td>
                    <td class="text-center align-middle text-black"><?php echo e($photo->title); ?></td>
                    <td class="text-center align-middle">
                        <img src="<?php echo e(asset('storage/'.$photo->image_path)); ?>" alt="<?php echo e($photo->title); ?>" width="300">
                    </td>
                    <td class="text-center align-middle">
                        <a href="<?php echo e(route('admin.photos.edit', $photo)); ?>" class="btn btn-sm btn-warning">Edit</a>
                        <form action="<?php echo e(route('admin.photos.destroy', $photo)); ?>" method="POST" class="d-inline-block" onsubmit="return confirm('Are you sure?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4">No photos found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Work\damiki\resources\views/admin/photos/index.blade.php ENDPATH**/ ?>