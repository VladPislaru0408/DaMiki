<?php $__env->startSection('content'); ?>
    <h2>Edit Photo</h2>
    <form action="<?php echo e(route('admin.photos.update', $photo)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div>
            <label for="title">Title (optional):</label>
            <input type="text" name="title" id="title" value="<?php echo e(old('title', $photo->title)); ?>">
        </div>
        <div>
            <label>Current Photo:</label>
            <img src="<?php echo e(asset('storage/' . $photo->image_path)); ?>" alt="<?php echo e($photo->title); ?>" width="100">
        </div>
        <div>
            <label for="photo">New Photo (if you want to update):</label>
            <input type="file" name="photo" id="photo">
        </div>
        <button type="submit">Update Photo</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Work\damiki\resources\views/admin/photos/edit.blade.php ENDPATH**/ ?>